import xbmcaddon

MainBase = 'https://goo.gl/CMBRki'
addon = xbmcaddon.Addon('plugin.video.joao')