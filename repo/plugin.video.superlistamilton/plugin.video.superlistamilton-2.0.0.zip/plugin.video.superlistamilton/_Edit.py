import xbmcaddon

MainBase = 'http://goo.gl/sEnA3m'
addon = xbmcaddon.Addon('plugin.video.superlistamilton')