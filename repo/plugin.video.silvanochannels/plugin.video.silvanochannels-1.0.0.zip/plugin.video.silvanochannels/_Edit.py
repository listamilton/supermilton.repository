import xbmcaddon

MainBase = 'http://silvanochannels.esy.es/canais-addon/home.txt'
addon = xbmcaddon.Addon('plugin.video.silvanochannels')